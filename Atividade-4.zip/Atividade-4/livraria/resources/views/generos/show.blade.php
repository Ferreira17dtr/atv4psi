ID:{{$genero->id_genero}}<br>
Desinação:{{$genero->designacao}}<br>
Observações:{{$genero->observacoes}}